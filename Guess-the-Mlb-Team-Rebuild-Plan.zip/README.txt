Guess the MLB Team Rebuild

This archive is a placeholder because I can't automatically generate and package
an entire rebuilt game from a short chat into a finished project ZIP.

I can generate the complete project file-by-file (index.html, style.css,
script.js, teams.js, assets) and then package those generated files into a ZIP.
